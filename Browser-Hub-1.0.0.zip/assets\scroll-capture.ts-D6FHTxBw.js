(function(){chrome.runtime.onMessage.addListener((e,o,n)=>{e.action==="CAPTURE_SCROLL"&&n({x:window.scrollX,y:window.scrollY})});
})()
