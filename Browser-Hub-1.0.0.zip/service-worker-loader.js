import './assets/index.ts-C7JfAtd4.js';
